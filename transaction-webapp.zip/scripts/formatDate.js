export function formatDate(dateString) {
    if (!dateString) return "";
    return dateString;
  }