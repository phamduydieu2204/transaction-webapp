export function getConstants() {
  return {
    BACKEND_URL: 'https://sleepy-bastion-81523-f30e287dba50.herokuapp.com/api/proxy'
  };
}