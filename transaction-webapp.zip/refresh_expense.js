window.expenseList = null; window.currentExpensePage = 1; import('./scripts/updateExpenseTable.js').then(m => m.updateExpenseTable());
